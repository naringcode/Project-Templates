﻿#pragma once

// 거의 사용되지 않는 내용을 Windows 헤더에서 제외합니다.
#define WIN32_LEAN_AND_MEAN

// 정적 라이브러리 내 사용할 헤더 파일은 "PublicPch.h" 내에 작성하고, 해당 프로젝트의 cpp 파일은 "CommonPch.h"를 사용하도록 한다.
// 외부 공개용 헤더 파일을 제공할 것인지는 선택 사항이다.
// - common : 내부 공유용
// - public : 외부 공개용
#include "PublicPch.h"
