﻿#pragma once

// 정적 라이브러리 내 사용할 헤더 파일은 "InternalPch.h" 내에 작성하고, 해당 프로젝트의 cpp 파일과 라이브러리를 포함하는 프로젝트는 "ExternalPch.h"를 사용하도록 한다.
// 외부 공개용 헤더 파일을 제공할 것인지는 선택 사항이다.
// - Internal : 내부 공유용
// - External : 외부 공개용
#include "ExternalPch.h"
