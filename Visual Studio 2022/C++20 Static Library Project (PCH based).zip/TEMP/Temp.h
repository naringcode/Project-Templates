#pragma once

void HelloWorld();
