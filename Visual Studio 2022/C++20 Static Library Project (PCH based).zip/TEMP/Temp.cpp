#include "InternalPch.h"

void HelloWorld()
{
    std::cout << "Hello World\n";
}
