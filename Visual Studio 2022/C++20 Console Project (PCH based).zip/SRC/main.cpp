#include "pch.h"

int main()
{
    std::cout << "Hello World\n";

    return 0;
}
